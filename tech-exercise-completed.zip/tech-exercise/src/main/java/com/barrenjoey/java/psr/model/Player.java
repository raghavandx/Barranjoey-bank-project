package com.barrenjoey.java.psr.model;

public class Player {
    private String name;
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
