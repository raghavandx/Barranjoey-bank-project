Thanks for taking the time to look at Barrenjoey Markets Technology java assessment.

In the directory structure you will find two exercises. They are located in the following packages:

com.barrenjoey.java.psr
This is an extremely simple version of the game Paper Scissors Rock. Please refactor this game with software engineering
SOLID principles in mind. See the README alongside the source file for more info.
In case you're unfamiliar with the SOLID acronym please see: https://en.wikipedia.org/wiki/SOLID

com.barrenjoey.java.bank
Here you will find a hopefully more interesting and open exercise. Simulating a situation where you are thrown in the
deep end without perhaps as much information as you would like.
Please don't be discouraged, use your experience to make some enginnering decisions and interpret the requirements
as best you can.

You will find a README file in each package with more information. Good luck!
